namespace LibLR1.Contracts
{
	public struct TrackQuaternion
	{
		public float X;
		public float Y;
		public float Z;
		public float W;

		public TrackQuaternion(float p_x, float p_y, float p_z, float p_w)
		{
			X = p_x;
			Y = p_y;
			Z = p_z;
			W = p_w;
		}
	}
}
