namespace LibLR1.Contracts
{
	public class TrackTransform
	{
		public TrackVector3 Position { get; set; }
		public TrackQuaternion Rotation { get; set; }
		public TrackVector3 Scale { get; set; }

		public TrackTransform()
		{
			Position = new TrackVector3(0f, 0f, 0f);
			Rotation = new TrackQuaternion(0f, 0f, 0f, 1f);
			Scale = new TrackVector3(1f, 1f, 1f);
		}
	}
}
