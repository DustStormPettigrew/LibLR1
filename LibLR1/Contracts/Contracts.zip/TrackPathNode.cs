namespace LibLR1.Contracts
{
	public class TrackPathNode
	{
		public TrackVector3 Position { get; set; }
		public TrackVector3 Forward { get; set; }
		public TrackVector3 Up { get; set; }
		public float Width { get; set; }

		public TrackPathNode()
		{
			Position = new TrackVector3(0f, 0f, 0f);
			Forward = new TrackVector3(0f, 0f, 1f);
			Up = new TrackVector3(0f, 1f, 0f);
			Width = 0f;
		}
	}
}
