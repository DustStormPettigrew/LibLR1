namespace LibLR1.Contracts
{
	public class TrackVertex
	{
		public TrackVector3 Position { get; set; }
		public TrackVector3 Normal { get; set; }
		public TrackVector2 PrimaryTexCoord { get; set; }
		public TrackColor Color { get; set; }

		public TrackVertex()
		{
			Position = new TrackVector3(0f, 0f, 0f);
			Normal = new TrackVector3(0f, 0f, 0f);
			PrimaryTexCoord = new TrackVector2(0f, 0f);
			Color = new TrackColor(1f, 1f, 1f, 1f);
		}
	}
}
