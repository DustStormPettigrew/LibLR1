namespace LibLR1.Contracts
{
	public struct TrackVector3
	{
		public float X;
		public float Y;
		public float Z;

		public TrackVector3(float p_x, float p_y, float p_z)
		{
			X = p_x;
			Y = p_y;
			Z = p_z;
		}
	}
}
