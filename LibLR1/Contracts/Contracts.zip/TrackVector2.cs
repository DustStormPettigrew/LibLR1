namespace LibLR1.Contracts
{
	public struct TrackVector2
	{
		public float X;
		public float Y;

		public TrackVector2(float p_x, float p_y)
		{
			X = p_x;
			Y = p_y;
		}
	}
}
